# CHANGELOG — LavoBCN

## v1.0.3 — 13 julio 2026 · Auditoría de producción
**Sin cambios de código.** Versión de auditoría y documentación.

### Auditoría ejecutada
- Sintaxis: 6 HTML + 5 módulos JS → 0 errores
- Funciones duplicadas: 8 detectadas y documentadas (no corregidas, ver motivo)
- Referencias onclick: 0 rotas
- Patrón de recursión (bug SS): no se repite
- Consistencia Firebase: nodos W/R correctos
- Motor único: estructura cliente = hotel verificada

### Riesgos documentados, NO corregidos
7 funciones duplicadas en cliente.html y 1 en rider.html (`mostrarLlamadaAuto`, firmas distintas).
**Motivo:** los servicios funcionan hoy; corregirlos son 8 intervenciones en archivos de 4.000 líneas sin poder probar en navegador. Prioridad declarada: no romper nada. Se propone eliminarlas de una en una, con checklist individual.

### Informes nuevos
- informes/INFORME-QA.md
- informes/INFORME-SEGURIDAD.md
- informes/INFORME-FIREBASE-RULES.md
- informes/INFORME-WORKER.md
- informes/INFORME-MIGRACION.md
- informes/LISTA-PRUEBAS-REALIZADAS.md

### NO incluido (y por qué)
Phone Auth, cierre de Firebase Rules y Worker como capa de escritura **no se entregan como código** porque requieren configuración en consola de Firebase y despliegue en Cloudflare, ambos fuera de mi acceso. Entregarlos sin esos pasos dejaría la app sin acceso. Especificación completa en INFORME-MIGRACION.md.

---
## v1.0.2 — Arquitectura definitiva (documentación)
## v1.0.1 — Motor único de pedidos (hoteles/empresas → /pedidos)
## v1.0.0 — Primera versión consolidada (CAMBIO 1 al 8)
